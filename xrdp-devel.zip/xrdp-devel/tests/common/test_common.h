
#ifndef TEST_COMMON_H
#define TEST_COMMON_H

#include <check.h>

Suite *make_suite_test_string(void);

#endif /* TEST_COMMON_H */